import FrameComponent4 from "../components/FrameComponent4";
import { useState } from 'react';
import axios from 'axios';
import "./SignUp.css";

const SignUp = () => {

  // Define state variables for form inputs
  const [userName, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone_Number, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');

  const handleUsername = (e) => {
    setName(e.target.value);
  }

  const handleEmail = (e) => {
    setEmail(e.target.value);
  }

  const handlePhoneNumber = (e) => {
    setPhoneNumber(e.target.value);
  }

  const handlePassword = (e) => {
    setPassword(e.target.value);
  }

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send the form data to the server
const response = await axios.post('http://plain-mirrors-nail.loca.lt/v1/signup', {
        userName: userName,
        email: email,
        phone_Number: phone_Number,
        password: password // Corrected variable name from Password to password
      });
      console.log(response?.data); // Use optional chaining to safely access data property
    } catch (error) {
      console.error('Error:', error.response?.data.message); // Use optional chaining to safely access response and data properties
    }
  }

  return (
    <div className="sign-up">
      <FrameComponent4 />
      <form onSubmit={handleSubmit}>
        <div className="sign-up-with" />
        <div className="sign-up-child" />
        <div className="sign-up-item" />
        <div className="sign-up-inner">
          <div className="o-r-parent">
            <div className="o-r">
              <div className="o-r-child" />
              <div className="o-r-item" />
              <div className="o-r-inner" />
            </div>
            <div className="mobile-no">
              <div className="email-input">
                <div className="sign-in-button">
                  <h1 className="create-free-account">Create Free Account</h1>
                </div>
                <div className="create-account-label">
                  <b className="sign-up-using">Sign up using social networks</b>
                </div>
                <div className="first-last-name-fields">
                  <div className="mobile-number-field">
                    <div className="email-field">
                      <div className="password-field">
                        <div className="terms-checkbox" />
                        <b className="f1">f</b>
                      </div>
                      <div className="password-field1">
                        <div className="password-field-child" />
                        <b className="g1">G+</b>
                      </div>
                      <div className="password-field2">
                        <div className="password-field-item" />
                        <b className="y1">Y</b>
                      </div>
                    </div>
                    <div className="o-r-text-parent">
                      <div className="o-r-text" />
                      <b className="or1">OR</b>
                      <div className="o-r-text1" />
                    </div>
                  </div>
                  <div className="contact-info-fields">
                    <div className="main-form">
                      <input
                        className="input-field-group"
                        placeholder={`First & Last Name`}
                        type="text"
                        value={userName}
                        onChange={handleUsername}
                      />
                      <input
                        className="register-button"
                        placeholder="Mobile no"
                        type="text"
                        value={phone_Number}
                        onChange={handlePhoneNumber}
                      />
                    </div>
                    <div className="main-form1">
                      <input
                        className="main-form-child"
                        placeholder="Email"
                        type="email"
                        value={email}
                        onChange={handleEmail}
                      />
                      <input
                        className="main-form-child"
                        placeholder="Password"
                        type="password"
                        value={password}
                        onChange={handlePassword}
                      />
                    </div>
                  </div>
                </div>
                <div className="sign-up-confirmation-message">
                  <input className="confirmation-frame1" type="checkbox" />
                  <b className="i-have-read">I have read the Terms & Conditions</b>
                </div>
                <div className="input-fields">
                  <button type="submit" className="submit-btn">
                    <div className="submit-btn-child" />
                    <b className="sign-up1">Sign up</b>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default SignUp;
