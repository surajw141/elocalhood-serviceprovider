import BackgroundFrame from "../components/BackgroundFrame";
import "./LogIn.css";
import axios from 'axios';

const LogIn = () => {
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Send the form data to the server
      const response = await axios.post('http://cool-cats-stick.loca.lt/v1/signup', {
        userName: userName,
        email: email,
        phoneNumber: phoneNumber,
        password: password
      });
      console.log(response?.data); // Use optional chaining to safely access data property
    } catch (error) {
      console.error('Error:', error.response?.data.message); // Use optional chaining to safely access response and data properties
    }
  }
  const validatePassword = (password) => {
    // Regular expressions for password validation
    const uppercaseRegex = /[A-Z]/;
    const lowercaseRegex = /[a-z]/;
    const specialCharRegex = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    const numberRegex = /[0-9]/;

    // Check if password meets all criteria
    return (
      uppercaseRegex.test(password) &&
      lowercaseRegex.test(password) &&
      specialCharRegex.test(password) &&
      numberRegex.test(password)
    );
  }

 
  
  return (
    <div className="log-in">
      <div className="frame-login">
        <div className="frame-content">
          <header className="framee-localhood">
            <div className="framee-localhood-child" />
            <h2 className="e-localhood">e-Localhood</h2>
          </header>
          <div className="frame-social-login">
            <form className="frame-email-mobile">
              <h1 className="login-to-your">Login to Your Account</h1>
              <div className="frame-button">
                <b className="login-using-social">
                  Login using social networks
                </b>
                <div className="frame-input-group">
                  <div className="input-password">
                    <div className="frames-loading-ellipse">
                      <div className="ellipse-a" />
                      <b className="f">f</b>
                    </div>
                    <div className="frames-loading-ellipse1">
                      <div className="frames-loading-ellipse-child" />
                      <b className="g">G+</b>
                    </div>
                    <div className="frames-loading-ellipse2">
                      <div className="frames-loading-ellipse-item" />
                      <b className="y">Y</b>
                    </div>
                  </div>
                  <div className="frame-o-r">
                    <div className="rectangle-divider" />
                    <b className="or">OR</b>
                    <div className="rectangle-divider1" />
                  </div>
                  <input
                    className="frame-email-mobile-input"
                    placeholder="Email /Mobile no"
                    type="email"
                  />
                  <input
                    className="frame-email-mobile-input1"
                    placeholder="Password"
                    type="password"
                    
                  />
                </div>
              </div>
              <div className="signup-container">
                <button className="login-button">
                  <div className="login-button-child" />
                  <b className="signin">Signin</b>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <BackgroundFrame />
    </div>
  );
};

export default LogIn;
