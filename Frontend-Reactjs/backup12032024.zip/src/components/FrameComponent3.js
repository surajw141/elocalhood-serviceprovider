import "./FrameComponent3.css";

const FrameComponent3 = () => {
  return (
    <div className="main-frame">
      <button className="seller-account-creation">
        <div className="seller-account-creation-child" />
        <b className="e-localhood3">e-Localhood</b>
      </button>
    </div>
  );
};

export default FrameComponent3;
